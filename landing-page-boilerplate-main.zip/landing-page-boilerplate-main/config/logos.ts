
export const LOGOS = [
  {
    name: "Next.js",
    image: "/images/techStack/nextjs.svg",
  },
  {
    name: "React",
    image: "/images/techStack/react.svg",
  },
  {
    name: "Tailwind",
    image: "/images/techStack/tailwind.svg",
  },
  {
    name: "Framer",
    image: "/images/techStack/framer.svg",
  },
  {
    name: "Shadcnui",
    image: "/images/techStack/shadcnui.svg",
  },
  {
    name: "Nextui",
    image: "/images/techStack/nextui.svg",
  },
  {
    name: "TS",
    image: "/images/techStack/typescript.svg",
  },
  {
    name: "Vercel",
    image: "/images/techStack/vercel.svg",
  },
];
